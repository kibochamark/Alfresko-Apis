import { eq } from "drizzle-orm";
import db from "../utils/connection"
import { users } from './schema';







export const getUsers = async () => {
    return await db.select({ id: users.id, email: users.email}).from(users);
}

